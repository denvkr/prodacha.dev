function leftcatalogmenu_click(){
	//alert('hello');
	document.getElementById('fade').style.display='block';
	//$(document).ready(function(){
	//$("#fade").css("display", "block"); 
	//$(document).find(".submenuhead").fadeOut('fast');//fadeTo('fast', 0);
	//$( event.target ).children(".submenuhead").fadeIn('fast');//fadeTo('fast', 1);
	//});
	//$(e.target).children(".submenuhead").fadeIn('fast');
}