$(document).ready(function() 
{
	$("#seotxt1").load("http://prodacha.ru/seotxt/seotxt1.txt");
	$("#seotxt2").load("http://prodacha.ru/seotxt/seotxt2.txt");
	$("#seotxt3").load("http://prodacha.ru/seotxt/seotxt3.txt");



;}
);
